from flask import render_template, flash, redirect
from app import app
from forms import LoginForm
"""
To render the templates, a function from the Flask frameworkcalled render_template 
is imported. This function takes a template filename and a variable
list of template arguments and returns the rendered template, with all the 
arguments replaced.

 """

@app.route('/index')
def index():
    
    return render_template('index.html')
    
"""
The  route decorators above the function create the mappings from 
URLs / and /index or /login to this function.
 """                          

@app.route('/')
@app.route('/login', methods=['GET', 'POST'])

def login():
    form = LoginForm()
    if form.validate_on_submit():
        ab=float(form.So.data)
        bc=float(form.Se.data)
        cd=float(form.Q.data)
        
        """
        The validate_on_submit method does all the form processing work. 
        If it is called when the form is being presented to the user 
        (i.e. before the user got a chance to enter data on it) then it will
        return False, to render the template.
        """
        """
        POST submits data to be processed (e.g., from an HTML form) to the identified 
        resource. The data is included in the body of the request. This may result in 
        the creation of a new resource or the updates of existing resources or both.
        GET requests a representation of the specified resource. It should not be
        used for operations that cause side-effects, such as using it for taking 
        actions in web applications. 
        One reason for this is that GET may be used arbitrarily by robots or crawlers,
        which should not need to consider the side effects that a request should cause.
        """
    
        Y=0.5
        "yield coefficient ie. mass of cells formed/mass of substrate utilized" 
        k=5.0 #1/day
        "maximum specific substrate utilization rate"
        Kd=0.06 #1/day
        "endogenous decay coefficient"
        Ks=100.0 #mg/l
        "saturation constant"
        f=0.675 
        "conversion factor for converting BOD5 to ultimate BOD"
        e=0.1
        "oxygen transfer effeciency"
        
        #adsjustable parameters
        X=2000.0 #mg/l
        "concentration of microbial mass"
    
        a=((Y*k*bc)/(Ks+bc))-Kd
        tc=1/a
        "Calculation of hydraulic retention time or period of aeration (t)"
        t=((tc*Y*(ab-bc))/(X*(1+tc*Kd)))*24
        "Volume of aeration tank"
        V=cd*t 
        "Treatment effeciency"
        n=((ab-bc)/ab)*100
        "Observed Yield"
        Yobs=(Y/(1+tc*Kd))
        "Mass of sludge wasted each day"
        P= (Yobs*cd*(ab-bc))/1000 #kg/day
        "Mass of oxygen required per day"
        m=((cd*(ab-bc))/(f*1000))-1.42*P #kg/day
        "Volume of air required"
        Va=(m/(1.185*0.232*e)) #m3/day
    
        
            
        flash('Volume of aeration tank required (m3) =  "%s"' %
              (V))
        flash('Time required for aeration of 1 unit (hrs) =  "%s"' %
              (t))
        flash('Mass of sludge wasted each day (kg/day) = "%s"' %
              (P))
        flash('Mass of oxygen required (kg/day)= "%s"' %
              (m))
        flash('Volume of air required (m3/day) = "%s"' %
              (Va))
        flash('Efficiency of treatment in percentage is "%s"' %
              (n))
                  
        """
        The flash function is a quick way to show a message on the next page
        presented to the user. 
        """
        return redirect('/index')
        
        """
        Redirect function tells the client web browser to navigate to a different
        page instead of the one requested. 
        Note that flashed messages will display even if a view function 
        ends in a redirect.
        """
        
    return render_template('login.html',
                            form=form)
                            
    """
    If the form is not valid, then it doesnt enters the if function and simply 
    goes back to login.html and relaunches it.
    """                      
                        
