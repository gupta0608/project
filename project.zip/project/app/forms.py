from flask.ext.wtf import Form
from wtforms import DecimalField
from wtforms.validators import DataRequired


class LoginForm(Form):
    
    So = DecimalField('So')
    Se = DecimalField('Se')
    Q = DecimalField('Q')